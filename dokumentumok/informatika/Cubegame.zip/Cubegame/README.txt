After you unzipped the file run the CubeGame named .exe file 
choose your settings and enjoy.
Created by Kollmann �ron, Rekenei Mil�n
And was supported by the shcool of Zugl�i Arany J�nos and AMI
Special thanks to Csonka Alex and Csurg� S�nor.